import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);
    const location = useLocation();

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 10);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const navigationItems = [
        {
            name: 'Início',
            path: '/',
            icon: 'Home',
        },
        {
            name: 'Sobre Nós',
            path: '/about-brand-story-credentials',
            icon: 'Users',
        },
        {
            name: 'FAQ',
            path: '/faq-comprehensive-buyer-education',
            icon: 'HelpCircle',
        },
    ];

    // Adiciona a aba de upload de imagens que aponta para a rota do painel
    const items = [...navigationItems, { name: 'Painel', path: '/painel', icon: 'Image', external: true }];

    const isActivePath = (path) => {
        return location?.pathname === path;
    };

    const handleWhatsAppClick = () => {
        const message = encodeURIComponent('Olá! Gostaria de saber mais sobre os imóveis disponíveis.');
        window.open(`https://wa.me/5562999999999?text=${message}`, '_blank');
    };

    return (
        <header
            className={`fixed top-0 right-0 left-0 z-50 transition-all duration-200 ${
                isScrolled ? 'shadow-subtle bg-white/95 backdrop-blur-sm' : 'bg-white'
            }`}
        >
            <div className="container-responsive">
                <div className="flex h-16 items-center justify-between">
                    {/* Logo */}
                    <Link to="/" className="flex items-center space-x-3 transition-opacity hover:opacity-80">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-secondary">
                            <Icon name="Home" size={24} color="white" strokeWidth={2.5} />
                        </div>
                        <div className="hidden sm:block">
                            <h1 className="text-text-primary text-xl font-bold">Casa Conecta</h1>
                            <p className="text-text-secondary text-xs font-medium">Imóveis Premium</p>
                        </div>
                    </Link>

                    {/* Desktop Navigation */}
                    <nav className="hidden items-center space-x-8 lg:flex">
                        {items?.map((item) =>
                            item?.external ? (
                                <a
                                    key={item?.path}
                                    href={item?.path}
                                    className={`text-text-secondary flex items-center space-x-2 rounded-md px-3 py-2 text-sm font-medium transition-all duration-200 hover:bg-primary/5 hover:text-primary`}
                                >
                                    <Icon name={item?.icon} size={18} />
                                    <span>{item?.name}</span>
                                </a>
                            ) : (
                                <Link
                                    key={item?.path}
                                    to={item?.path}
                                    className={`flex items-center space-x-2 rounded-md px-3 py-2 text-sm font-medium transition-all duration-200 ${
                                        isActivePath(item?.path)
                                            ? 'bg-primary/10 text-primary'
                                            : 'text-text-secondary hover:bg-primary/5 hover:text-primary'
                                    }`}
                                >
                                    <Icon name={item?.icon} size={18} />
                                    <span>{item?.name}</span>
                                </Link>
                            ),
                        )}
                    </nav>

                    {/* Desktop CTA */}
                    <div className="hidden items-center space-x-4 lg:flex">
                        <Button
                            variant="outline"
                            size="sm"
                            iconName="Phone"
                            iconPosition="left"
                            onClick={() => window.open('tel:+5562999999999')}
                            className="text-text-secondary border-border hover:border-primary hover:text-primary"
                        >
                            (62) 99999-9999
                        </Button>
                        <Button
                            variant="default"
                            size="sm"
                            iconName="MessageCircle"
                            iconPosition="left"
                            onClick={handleWhatsAppClick}
                            className="bg-accent hover:bg-accent/90"
                        >
                            WhatsApp
                        </Button>
                    </div>

                    {/* Mobile Menu Button */}
                    <button
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                        className="text-text-secondary rounded-md p-2 transition-colors hover:bg-primary/5 hover:text-primary lg:hidden"
                        aria-label="Toggle mobile menu"
                    >
                        <Icon name={isMobileMenuOpen ? 'X' : 'Menu'} size={24} />
                    </button>
                </div>

                {/* Mobile Menu */}
                {isMobileMenuOpen && (
                    <div className="border-t border-border bg-white lg:hidden">
                        <div className="container-responsive">
                            <div className="space-y-3 py-4">
                                {items?.map((item) =>
                                    item?.external ? (
                                        <a
                                            key={item?.path}
                                            href={item?.path}
                                            onClick={() => setIsMobileMenuOpen(false)}
                                            className={`text-text-secondary flex items-center space-x-3 rounded-md px-3 py-3 text-sm font-medium transition-all duration-200 hover:bg-primary/5 hover:text-primary`}
                                        >
                                            <Icon name={item?.icon} size={20} />
                                            <span>{item?.name}</span>
                                        </a>
                                    ) : (
                                        <Link
                                            key={item?.path}
                                            to={item?.path}
                                            onClick={() => setIsMobileMenuOpen(false)}
                                            className={`flex items-center space-x-3 rounded-md px-3 py-3 text-sm font-medium transition-all duration-200 ${
                                                isActivePath(item?.path)
                                                    ? 'bg-primary/10 text-primary'
                                                    : 'text-text-secondary hover:bg-primary/5 hover:text-primary'
                                            }`}
                                        >
                                            <Icon name={item?.icon} size={20} />
                                            <span>{item?.name}</span>
                                        </Link>
                                    ),
                                )}

                                <div className="space-y-3 border-t border-border pt-4">
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        iconName="Phone"
                                        iconPosition="left"
                                        onClick={() => {
                                            window.open('tel:+5562999999999');
                                            setIsMobileMenuOpen(false);
                                        }}
                                        fullWidth
                                        className="text-text-secondary justify-start border-border hover:border-primary hover:text-primary"
                                    >
                                        (62) 99999-9999
                                    </Button>
                                    <Button
                                        variant="default"
                                        size="sm"
                                        iconName="MessageCircle"
                                        iconPosition="left"
                                        onClick={() => {
                                            handleWhatsAppClick();
                                            setIsMobileMenuOpen(false);
                                        }}
                                        fullWidth
                                        className="justify-start bg-accent hover:bg-accent/90"
                                    >
                                        Falar no WhatsApp
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </header>
    );
};

export default Header;
