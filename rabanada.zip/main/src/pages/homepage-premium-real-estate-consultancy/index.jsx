import React, { useEffect } from 'react';
import Header from '../../components/ui/Header';
import HeroCarousel from './components/HeroCarousel';
import FeaturedProperties from './components/FeaturedProperties';
import ExpertiseSection from './components/ExpertiseSection';
import NeighborhoodMap from './components/NeighborhoodMap';
import WhatsAppFloat from './components/WhatsAppFloat';
import ProcessTransparencySection from '../about-brand-story-credentials/components/ProcessTransparencySection';
import Footer from '../../components/Footer';

const HomepagePremiumRealEstateConsultancy = () => {
  useEffect(() => {
    // Smooth scroll behavior for anchor links
    const handleAnchorClick = (e) => {
      const href = e?.target?.getAttribute('href');
      if (href && href?.startsWith('#')) {
        e?.preventDefault();
        const element = document.querySelector(href);
        if (element) {
          element?.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    return () => document.removeEventListener('click', handleAnchorClick);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <Header />
      
      {/* Main Content */}
      <main>
        {/* Hero Carousel - Full viewport section */}
        <HeroCarousel />
        
        {/* Featured Properties - Well organized section */}
        <section className="section-spacing">
          <div className="container-responsive">
            <FeaturedProperties />
          </div>
        </section>

        {/* Neighborhood Map - Interactive section */}
        <section className="section-spacing">
          <div className="container-responsive">
            <NeighborhoodMap />
          </div>
        </section>

        {/* Expertise Section - Professional spacing */}
        <section className="section-spacing">
          <div className="container-responsive">
            <ExpertiseSection />
          </div>
        </section>

        {/* Transparent Process Section */}
        <ProcessTransparencySection />
      </main>

      {/* Footer */}
      <Footer />
      
      {/* WhatsApp Float Button */}
      <WhatsAppFloat />
    </div>
  );
};

export default HomepagePremiumRealEstateConsultancy;