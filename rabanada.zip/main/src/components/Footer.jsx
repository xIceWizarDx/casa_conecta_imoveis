export { default } from '../../../resources/js/main/components/Footer';
